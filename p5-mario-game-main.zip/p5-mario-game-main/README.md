## a simple mario game written in p5.js

branches:
main is same as 01-starter, project scaffold
-- assets + libraries
-- a few utilities for loading image chunks from spritesheets
-- a background and some ground

02 - Coins
-- a Coin class to display some coins

03 - Mario class
-- moving, jumping

04 - Game
-- refactor to have a Game class
-- start screen, game over screen, scoreboard, sounds

05 - enemies
-- collisions
-- collect coins
-- enemies
-- timer/countdown

-- things you can do --
turn it into a scrolling landscape! in other words, make it longer the current window, and have the landscape move while mario stays in place!
add levels
more enemies or rewards
more landscape features
